# Review-anime-2

Ajustei o código para interação das estrelas. Aliás, deixei como "AnimeLife" pois foi o nome original né xD
